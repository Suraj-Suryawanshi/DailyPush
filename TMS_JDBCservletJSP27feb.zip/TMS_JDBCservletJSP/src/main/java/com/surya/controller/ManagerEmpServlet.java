package com.surya.controller;

import java.io.IOException;
import java.sql.SQLException;
import java.util.List;

import com.surya.dao.EmpTaskDao;
import com.surya.dao.EmpTaskDaoImpl;
import com.surya.dao.TaskDao;
import com.surya.dao.TaskDaoImpl;
import com.surya.dao.UserDao;
import com.surya.dao.UserDaoImpl;
import com.surya.model.EmpTask;
import com.surya.model.Task;
import com.surya.model.User;

import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

@WebServlet("/managerEmpServlet")
public class ManagerEmpServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	UserDao userDao= new UserDaoImpl();
	TaskDao taskDao = new TaskDaoImpl();
	EmpTaskDao empTaskDao = new EmpTaskDaoImpl();

	@Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

    	List<User> employeeList = userDao.employeeUserList();
        request.setAttribute("employeeList", employeeList);
        System.out.println("doGet>>>>>>employeeList"+employeeList);
        RequestDispatcher dispatcher = request.getRequestDispatcher("AssignEmpTask.jsp");
        dispatcher.forward(request, response);

	}

	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {


	       String action = request.getParameter("sbt");
	       System.out.println("action>>>>>"+action);
	        if (action != null) {
	        	System.out.println("action call" + action);
	    		if (action != null) {
	    			if ("add".equals(action)) {
	    				
							addTask(request, response);
						
	    			} else if ("delete".equals(action)) {
	    				
							deleteTask(request, response);
						
	    			} else if ("edit".equals(action)) {
	    				try {
							edit(request, response);
						} catch (ServletException | IOException | SQLException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
	    			}
	    			else if("edit".equals(action)) {
	    				editTask(request,response);
	    			}
	    			else if("getAll".equals(action)) {
	    				getAllTask(request, response);
	    			}
	    			else {
	    				response.sendRedirect("ViewAssignTask.jsp");
	    			}
	    		}

	        }

	    }
		
		
    private void editTask(HttpServletRequest request, HttpServletResponse response) {
    	 System.out.println("taskServlet::editTask>>>>call");

	        int empTaskId = Integer.parseInt(request.getParameter("empTaskId"));
	        String empUserEmail=request.getParameter("empUserEmail");
	        int taskId_fKey=Integer.parseInt(request.getParameter("taskId_fKey"));
	        
	        EmpTask empTask=new EmpTask(empTaskId, empUserEmail, taskId_fKey)  ;
	        System.out.println("servlet>>>>>"+empTask);
	        // Update task in the taskService
	        empTaskDao.updateTask(empTask);
//     }

     response.sendRedirect("adminDispTask.jsp");
		
	}

	private void deleteTask(HttpServletRequest request, HttpServletResponse response) {
		// TODO Auto-generated method stub
		
	}

	private void addTask(HttpServletRequest request, HttpServletResponse response) throws SQLException, IOException, ServletException {
		EmpTask empTask = new EmpTask();
        empTask.setEmpUserEmail(request.getParameter("empUserEmail"));
        empTask.setTaskId_fKey(Integer.parseInt(request.getParameter("taskId_fKey")));
       
        empTaskDao.addEmpTask(empTask);
        System.out.println("tasksServlet::addTask>>>>>>>>>>>>"+empTask);
        
	}

		
		
		

}
