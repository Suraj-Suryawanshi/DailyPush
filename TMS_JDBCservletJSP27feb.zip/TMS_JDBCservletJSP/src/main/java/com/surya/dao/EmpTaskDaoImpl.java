package com.surya.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.surya.model.EmpTask;
import com.surya.util.DButil;

public class EmpTaskDaoImpl implements EmpTaskDao{
	
//	@Override
	public boolean addEmpTask(EmpTask empTask) throws SQLException {
		   String query = "INSERT INTO \"I1292\".empTask (empUserEmail, taskId_fKey ) VALUES (?, ?)";
	       System.out.println("task add::daoImpl----");
	        try (
	        	Connection connection = DButil.getConnection();
	            PreparedStatement preparedStatement = connection.prepareStatement(query)) {

	        	System.out.println("insideTry"+query);
	        	preparedStatement.setString(1, empTask.getEmpUserEmail());
	        	preparedStatement.setInt(2, empTask.getTaskId_fKey());
	        	

	            int rowsAffected = preparedStatement.executeUpdate();
	            System.out.println("addEmpTask::EmpTaskDaoImpl-----------"+rowsAffected);
	            return rowsAffected > 0;
	        }
	        catch (SQLException e) {
	            e.printStackTrace();
	            return false;
	        }

	}

	public List<EmpTask> selectAllEmpTask() throws SQLException {
		System.out.println("selectAllTask::Call----------");
    	String query= "select * from \"I1292\".empTask";
        List <EmpTask> empTasks = new ArrayList < > ();
        // Step 1: Establishing a Connection
        Connection connection = DButil.getConnection();
        try (
            // Step 2:Create a statement using connection object
            PreparedStatement preparedStatement = connection.prepareStatement(query);) {
            System.out.println(preparedStatement);
            // Step 3: Execute the query or update query
            ResultSet rs = preparedStatement.executeQuery();
            System.out.println("selectAllEmpTask::ResultSet--------"+rs);
            // Step 4: Process the ResultSet object.
            while (rs.next()) {
                int empTaskId = rs.getInt("empTaskId");
                String taskUserEmail = rs.getString("taskUserEmail");
                int taskId_fKey = rs.getInt("taskId_fKey");
               
                empTasks.add(new EmpTask(empTaskId,taskUserEmail,taskId_fKey));
                System.out.println("\nselectAllEmpTask::userDaoImpl-------"+empTasks);

            }
        }
		        catch (SQLException e) {
		        	e.printStackTrace();

		        }
//		        finally {
//					connection.close();
//				}
				return empTasks;

	}


}
