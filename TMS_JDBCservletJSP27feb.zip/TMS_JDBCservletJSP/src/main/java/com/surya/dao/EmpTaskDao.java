package com.surya.dao;

import java.sql.SQLException;
import java.util.List;

import com.surya.model.EmpTask;
import com.surya.model.Task;

public interface EmpTaskDao {
//	public List<Task> selectAllEmpTask() throws SQLException;
	public List<EmpTask> selectAllEmpTask() throws SQLException;
	public boolean addEmpTask(EmpTask empTask) throws SQLException;
}
