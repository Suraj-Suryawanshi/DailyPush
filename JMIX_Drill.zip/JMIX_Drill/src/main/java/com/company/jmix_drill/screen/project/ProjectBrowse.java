package com.company.jmix_drill.screen.project;

import io.jmix.ui.screen.*;
import com.company.jmix_drill.entity.Project;

@UiController("Project.browse")
@UiDescriptor("project-browse.xml")
@LookupComponent("projectsTable")
public class ProjectBrowse extends StandardLookup<Project> {
}