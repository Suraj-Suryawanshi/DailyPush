package com.company.jmix_drill.screen.timeentry;

import io.jmix.ui.screen.*;
import com.company.jmix_drill.entity.TimeEntry;

@UiController("TimeEntry.edit")
@UiDescriptor("time-entry-edit.xml")
@EditedEntityContainer("timeEntryDc")
public class TimeEntryEdit extends StandardEditor<TimeEntry> {
}