package com.surya.controller;

import jakarta.security.auth.message.callback.PrivateKeyCallback.Request;
import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import java.io.IOException;
import java.util.List;

import com.surya.dao.TaskDao;
import com.surya.dao.TaskDaoImpl;
import com.surya.dao.UserDao;
import com.surya.dao.UserDaoImpl;
import com.surya.model.Task;
import com.surya.model.User;

/**
 * Servlet implementation class ManagerServlet
 */
public class ManagerServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	UserDao userDao= new UserDaoImpl();
	TaskDao taskDao = new TaskDaoImpl();

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

    	List<User> employeeList = userDao.employeeUserList();
        request.setAttribute("employeeList", employeeList);
        System.out.println("doGet>>>>>>employeeList"+employeeList);
        RequestDispatcher dispatcher = request.getRequestDispatcher("assignEmpTask.jsp");
        dispatcher.forward(request, response);


	}
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		HttpSession session = request.getSession();
		String email=(String)session.getAttribute("userEmail"); 
		System.out.println("\n\nJSP======="+email+"\n\n");
		Task task = taskDao.getTaskByManagerName(email);
		System.out.println("taskByManagerName::ManagerServlet"+task);
		RequestDispatcher dispatcher = request.getRequestDispatcher("ViewAssignTask.jsp");
		dispatcher.forward(request, response);
	}
}
